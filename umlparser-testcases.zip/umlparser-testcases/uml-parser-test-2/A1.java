 

public interface A1 {
 
}
 
