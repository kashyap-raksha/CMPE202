 

public class B1 extends P implements A1 {
 
}
 
