 

public interface A2 {
 
}
 
