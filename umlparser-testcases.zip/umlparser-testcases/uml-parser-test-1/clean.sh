rm *.class
