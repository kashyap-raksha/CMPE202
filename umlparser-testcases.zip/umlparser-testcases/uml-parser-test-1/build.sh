javac *.java
